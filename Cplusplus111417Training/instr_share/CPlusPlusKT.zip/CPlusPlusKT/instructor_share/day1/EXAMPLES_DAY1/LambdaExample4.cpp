#include<iostream>
using namespace std;

int main()
{
	int a = 10, b = 20;
	cout << "inside main...." << endl;
	cout << "a=" << a << ",b=" << b << endl;
	//define a lambda
	auto lm1 = [=]() mutable
	{
		//By default all outer-scope elements captured by value inside of a lambda
		//are treated as 'const' elements
		/*
		 const int a = main::a;
		 const int b = main::b;
		*/

		a = a + 100;
		b = b + 100;
		cout << "inside lambda...." << endl;
		cout << "a=" << a << ",b=" << b << endl;
	};
	//invoke the lambda
	lm1();

	cout << "After calling lambda...." << endl;
	cout << "inside main...." << endl;
	cout << "a=" << a << ",b=" << b << endl;

	lm1();
	a = 1000;
	b = 1000;
	lm1();
	return 0;
}