#include<iostream>
using namespace std;

int main()
{
	//define a lamba with a handle, so that it can be invoked more than once,
	//wherever inside the same function as desired by the programmer

	auto lm1 = []()
	{
		cout << "lambda called" << endl;
	};

	//invoke the lambda
	lm1();
	lm1();
	//*****************************************
	int a = 10, b = 20;

	auto lm2 = [&]() ->void
	{
		cout << "a:" << a << endl;
		cout << "b:" << b << endl;
	};

	lm2();
	//************************************
	auto lm3 = [](int x)  -> int
	{
		return x + 10;
	};

	auto result1 = lm3(100);
	cout << "result1 =" << result1 << endl;
	return 0;
}