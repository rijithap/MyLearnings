#include<iostream>
using namespace std;

int main()
{
	int a = 10, b = 20;
	cout << "inside main...." << endl;
	cout << "a=" << a << ",b=" << b << endl;
	//define a lambda
	auto lm1 = [&]()
	{
		/*
		 int& a = main::a;
		 int& b = main::b;
		*/
		a = a + 100;
		b = b + 100;
		cout << "inside lambda...." << endl;
		cout << "a=" << a << ",b=" << b << endl;
	};
	//invoke the lambda
	lm1();

	cout << "After calling lambda...." << endl;
	cout << "inside main...." << endl;
	cout << "a=" << a << ",b=" << b << endl;

	return 0;
}