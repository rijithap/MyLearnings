#include<iostream>
#include<list>
#include<algorithm>
using namespace std;

class CA
{
private:
	int a, b;
public:
	CA(int x = 0, int y = 0) :a(x), b(y) { }
	void print() const { cout << "a:" << a << ",b:" << b << endl; }
	/*
	In C++ 98, FUNCTOR's are the only class methods, that can be directly
	invoked by an STL algorithm and no other member function.
	*/
	void operator()(CA& ob)
	{
		cout << "functor called" << endl;
		cout << "a:" << ob.a << ",b:" << ob.b << endl;
	}
	/*
	void business1(){...}
	void business2(){....}
	*/
};


//consumer code.....
void Print(CA& ob)
{
	ob.print();
}

int main()
{
	list<CA> ls1;
	//populate the container with few CA objects
	for (int i = 1; i <= 5; i++)
	{
		ls1.push_back(CA(i, i + 10));
	}
	/*
	list<CA>::iterator itr = ls1.begin();
	while (itr != ls1.end())
	{
		itr->print();
		itr++;
	}
	*/
	//for_each(ls1.begin(), ls1.end(), Print);

	CA obj; //dummy object, just to bind to the functor...
	for_each(ls1.begin(), ls1.end(), obj);
	                            //, obj.operator()(object_from_ls1);
	return 0;
}