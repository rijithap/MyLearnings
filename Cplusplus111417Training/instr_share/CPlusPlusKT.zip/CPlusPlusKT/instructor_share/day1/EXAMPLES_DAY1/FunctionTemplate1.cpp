#include<iostream>
using namespace std;

//An example on function template supporting multiple typenames....
/* version-1
template<typename T1, typename T2> T1 Add(T1 x, T2 y)
{
	return x + y;
}
*/
/*
//version-2
template<typename T1, typename T2, typename T3> T3 Add(T1 x, T2 y)
{
	return x + y;
}
*/
//version-3
template<typename T1, typename T2, typename T3> T1 Add(T2 x, T3 y)
{
	return x + y;
}
//***consumer code****
int main()
{
	float x;
	//x = Add<float, int,float>(12.34f, 100);  //explicit instantiation
	x = Add<float>(12.34f, 100);  //explicit cum implicit instantiation
	cout << "x=" << x << endl;
	cout << "-----------------" << endl;
	//x = Add<int,float,float>(100, 12.34f);
	x = Add<float>(100, 12.34f);
	cout << "x=" << x << endl;
	return 0;
}