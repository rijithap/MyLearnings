#include<iostream>
#include<functional>
using namespace std;

int main()
{
	//auto lm = []() ->void
	function<void(void)> lm1 = []() ->void
	{
		cout << "lambda called" << endl;
		cout << __FUNCSIG__ << endl;
		cout << __FUNCTION__ << endl;
	};

	lm1();    // lm1.operator()();
	return 0;
}