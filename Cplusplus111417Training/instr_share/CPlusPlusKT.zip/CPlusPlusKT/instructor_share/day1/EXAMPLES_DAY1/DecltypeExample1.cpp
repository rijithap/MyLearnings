#include<iostream>
using namespace std;
//an example on decltype - type inference construct.

int main()
{
	int a{};
	auto b{ 100 };
	//--------------
	decltype(a) c{ 200 };
	decltype(b) d{ 300 };
	cout << "data type of a is :" << typeid(a).name() <<",it's value:" << a << endl;
	cout << "data type of b is :" << typeid(b).name() << ",it's value:" << b << endl;
	cout << "-----------------------" << endl;
	cout << "data type of c is :" << typeid(c).name() << ",it's value:" << c << endl;
	cout << "data type of d is :" << typeid(d).name() << ",it's value:" << d << endl;
	cout << "-----------------" << endl;
	const int e = 100;
	//decltype(e) f;         // ---> const int f;   will throw error as it is not init.
	decltype(e) f{ 200 };   // --> const int f=200;  //ok
	cout << "--------------------" << endl;

	int x = 100;
	decltype((x)) y1{x};   // int& y1{x} , now 'y1' is another name for 'x'

	cout << "x:" << x << endl;
	cout << "y1" << y1 << endl;
	y1 = 200;
	cout << "x:" << x << endl;
	cout << "y1" << y1 << endl;
	return 0;
}