#include<iostream>
#include<list>
#include<algorithm>
using namespace std;

class CA
{
private:
	int a, b;
public:
	CA(int x = 0, int y = 0) :a(x), b(y) { }
	void print() const { cout << "a:" << a << ",b:" << b << endl; }
	void business1() {	cout << "CA business1 called" << endl; 	}
	void business2() {	cout << "CA business2 called" << endl; 	}
};


int main()
{
	list<CA> ls1;
	//populate the container with few CA objects
	for (int i = 1; i <= 5; i++)
	{
		ls1.push_back(CA(i, i + 10));
	}
	auto print = [](CA& ob)
	{
		ob.print();
	};

	auto b1 = [](CA& ob)
	{
		ob.business1();
	};

	auto b2 = [](CA& ob)
	{
		ob.business2();
	};
	//************************************************
	for_each(ls1.begin(), ls1.end(), print);
	cout << "-------------------------" << endl;
	for_each(ls1.begin(), ls1.end(), b1);
	cout << "-------------------------" << endl;
	for_each(ls1.begin(), ls1.end(), b2);
	         //(or)
	for_each(ls1.begin(), ls1.end(), [](CA& ob) {ob.business2(); });
	return 0;
}