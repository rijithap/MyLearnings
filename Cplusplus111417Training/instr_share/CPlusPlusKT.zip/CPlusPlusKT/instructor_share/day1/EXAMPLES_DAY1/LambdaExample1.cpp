#include<iostream>
using namespace std;

//A simple usage of lambda function

int main()
{
	//define a lambda
	[]() -> void
	{
		cout << "lambda called..." << endl;
		//...
	}();    // and call or implement the lambda [in-place call]
	
	return 0;
}